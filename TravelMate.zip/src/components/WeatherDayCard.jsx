export default function WeatherDayCard({
  day,
  weather,
  onEdit,
}) {

  return (

    <div className="rounded-2xl bg-white p-5 shadow">

      <div className="flex items-center justify-between">

        <div>

          <div className="text-sm font-semibold text-blue-500">

            {day.date}

          </div>

          <div className="mt-2 text-lg font-bold">

            📍 {day.city}

          </div>

        </div>

        <button
          onClick={onEdit}
          className="rounded-lg p-2 text-xl transition hover:bg-gray-100"
        >
          ✏️
        </button>

      </div>

      {weather ? (

        <div className="mt-6">

          <div className="flex items-center justify-between">

            <div>

              <div className="text-lg font-semibold">

                {weather.day.condition.text}

              </div>

              <div className="mt-2 text-2xl font-bold">

                {weather.day.mintemp_c}° ~ {weather.day.maxtemp_c}°

              </div>

            </div>

            <img
              src={weather.day.condition.icon}
              alt=""
              className="h-16 w-16"
            />

          </div>

          <div className="mt-5 flex justify-between text-sm text-gray-500">

            <span>

              ☔ {weather.day.daily_chance_of_rain}%

            </span>

            <span>

              💨 {weather.day.maxwind_kph} km/h

            </span>

          </div>

        </div>

      ) : (

        <div className="mt-6 text-gray-400">

          讀取天氣中...

        </div>

      )}

    </div>

  );

}